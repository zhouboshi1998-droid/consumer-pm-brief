---
name: consumer-pm-daily-brief
description: >-
  消费PM每日简报。覆盖A股+港股消费 ~262只核心标的，六源取数(comein/info-bridge/iFind/Wind/AceCamp/本地ThirdBridge存档)
  → 按重要性分级 + 来源类型分区(公司动态/行情数据/券商观点/专家纪要/市场段子) → 变化优先、事实观点分离成稿
  → 输出三件(精简版.txt + 详细版.md + 仪表盘.html)。早报(~8:00)+晚报(~16:30)工作日双跑。
  触发词:"跑消费日报/早报/晚报"、"消费PM简报"、"consumer-pm-brief"、"consumer daily brief"。
  约束:不代研究员下评级/仓位/时点决策;草稿审签后手动发送。
version: 2.0-wb
agent_created: true
---

# 消费PM每日简报 · consumer-pm-daily-brief (WorkBuddy版)

你是研究助手，产出消费组PM每日消费简报草稿。
完整设计文档见 `自动化工作流-skill合集/F_日报与定时跟踪/consumer-pm-daily-brief/设计文档_v1.md`。

> **总要求**
> ① 关注变化——事实区只摘重要变化;券商区只列 🔼上调/🔽下调/盈利预测调整/观点转向,例行"维持推荐"折叠。
> ② 注重时效性——优先当日/近2-3天边际,旧信号折叠。
> ③ 区分事实与观点——按来源类型分区(§5.2)。
> ④ 客观数据必须查实——金价/批价/股价/汇率走WebSearch或接口核实,禁堆进"未验证段子"区。
> ⑤ 少加AI判断演绎——以事实陈述为主。

---

## 0. 服务对象与定位

- 服务消费组PM,看消费11年、能独立判断。要"1小时过一遍整个消费品"。
- 判断归研究员:起草草稿,研究员签字/改/毙后发。不碰仓位/止损/入场时点/精确目标价。
- 推送全手动:只产出草稿(文本+HTML落盘),不自动发送。

## 1. 节奏(早晚双跑)

| 跑次 | 时间 | 内容 |
|---|---|---|
| 早报 | 盘前 ~08:00 | 隔夜外盘消费/中概、昨夜今晨公告数据、今日披露日历、卖方今晨主推 |
| 晚报 | 盘后 ~16:30 | 全天公告/业绩/调研反馈/卖方异动/资金/消费数据 |

周末/周一覆盖上一交易日。自动化配置见 §9。

## 2. 四层流水线

```
L0 取数      五源并行取数(§4),raw落盘,不占主上下文
L1 浓缩初筛   跨源去重 + 打标(标的/主题·信号类型·是否持仓·是否敏感)
L2 策展+判级   重要性分级(§5.1) + 卖方解码(§6) + 来源分区成稿(§5.2) + 三点判断校准
L3 输出落盘   精简版.txt + 详细版.md + 仪表盘.html;chat汇报关键变化
```

## 3. 覆盖范围与标的池(两层)

**标的池 = `references/coverage_universe.json`**(核心 ~262 + 扩展申万9行业全集):
- **核心池(core · 逐家深扫)**:11组 ~262家 = 酒类/非酒食品/农业/汽车/家电/社服美护/零售纺服/轻工/中概港股平台/新茶饮咖啡/港股新消费餐饮。逐家公司名分组查询,深做。
- **扩展池(extended · 只报异动)**:申万9大消费行业全集(~1043家A股+港股/中概),按行业动态扫描业绩预告/快报/重大公告/股价异动,命中且不在core → 报异动(不逐家深扫)。名册参考 `references/extended_roster_20260629.md`。

**深度加权**:
- 重点层(深):食饮(酒类+非酒食品)+ 商贸零售/纺服 + 中概港股平台/新茶饮咖啡/港股餐饮。
- 泛消费层(仅标边际):农业/汽车/家电/轻工/社服美护——只捞重大业绩异动/重大公告/大主题。

## 4. 六源取数矩阵(并行派发·取数不占主上下文)

**WorkBuddy取数策略**:使用Agent工具并行派发多个子任务,每个子任务各自调用一个数据源的MCP/API。L0取数全部异步完成后,主上下文做L1-L3。

| 源 | 工具 | 取什么 | 等级 |
|---|---|---|---|
| **comein**(进门BRM) | Comein MCP: search_domestic_reports / search_analyst_comments / search_roadshow_summary | 内资研报、卖方点评、路演纪要 | B/C |
| **info-bridge**(讯息之桥) | Info-Bridge MCP: retrieve | 市场段子/叙事/情绪/分歧 | ⚠️未验证 |
| **iFind** | iFind MCP: search_news / search_notice / get_stock_financials | A股公告+新闻+一致预期 | 事实 |
| **Wind** | Wind MCP: get_stock_quote / get_stock_fundamentals / search_stocks | 港股行情+财务+FMP外盘 | 事实 |
| **AceCamp** | Python API脚本: `acecamp_client.py search/knowledge_search/recent_meetings` | 专家纪要、行业调研、近期会议列表 | B/C |
| **本地+ThirdBridge** | 文件系统读取本地归档 + FMP quote(美股) | 隔夜外盘行情、ThirdBridge专家访谈存档 | B |

**源角色分工**:
- **comein** = 卖方研报主源(内资+外资),**必须按全部11个子板块分query搜索,禁止仅搜食饮**。
  - 必搜子板块: 白酒/乳制品+食品/调味品+啤酒/黄金珠宝/汽车/家电/农业+养殖/社服美护/零售纺服/轻工/中概港股
  - 每条query为中文自然语言(如"汽车 比亚迪 吉利 赛力斯 销量 业绩 智能驾驶"),topK=5-8,窗口近2-3天
- **info-bridge** = 市场段子/叙事唯一源,关键词非自然语言,metadata_filter限近3天,每天配额30次收紧
- **iFind** = A股公告+一致预期,公告不可用时走WebSearch兜底
- **Wind** = 港股行情+财务主源,美股FMP兜底
- **AceCamp** = 专家纪要/行业调研主源,通过Python API脚本调用
- **本地+ThirdBridge** = 美股中概行情 + ThirdBridge专家访谈本地存档读取

**配额纪律**:comein按条扣费,收紧query数(≤8-16次);info-bridge每天30次;FMP港股quote绝对价失真→仅取涨跌方向,绝对价WebSearch校实;AceCamp API timeout 300s。

**取数后**:券商点评经§6解码(focus变化),info-bridge段子标[未验证]分层,客观数据(金价/批价/股价)查实。

## 5. 分级与分区

两步:① 按重要性决定上不上、详不详 → ② 按来源类型分区呈现。

### 5.1 重要性分级(折叠≠删除)
- **重点详写**:有 公司指引/盈利预测调整/重大公告/股价异动(±5%)/行业拐点 → 3句段子。
- **一行扫过**:有变化非实质(评级单动/调研/小公告)。
- **折叠状态**:无变化(≥3天老叙事)→ 压一行或行业汇总,不丢。

### 5.2 来源类型分区(呈现骨架)

| 区 | 性质 | 取什么 |
|---|---|---|
| 一、公司动态 | **【事实】** | 公告/业绩会/股东会(一手)——只列变化 |
| 二、行情/数据 | **【事实】** | 股价异动/金价/批价(可查证)——只摘最重要变化 |
| 三、券商观点 | **【观点】** | 🔼上调/🔽下调/盈利预测调整/观点转向(维持类折叠) |
| 四、专家纪要 | 事实/观点 | `主题 | 来源 | 时间 | 专家背景`(背景必标) |
| 五、市场段子 | **【观点·未验证】** | info-bridge流传,标[L1传闻]/[L2卖方圈内],禁当事实 |
| 附、一致预期 | 参考 | iFind,标"滞后、仅作估值参考、不作判断锚" |

横切情绪标签(选用):亢奋/平淡/转谨慎(亢奋+已涨多 = 拥挤顶部反读)。

## 6. 卖方信号解码模块

**第一性原理**:A股卖方评级是压缩刻度(没"小杯"),真信号在 ① 盈利预测/目标价的量化修正 ② 看多程度梯度。

**conviction梯度 0–5**:5超大杯(首推+上调EPS+上调TP+进金股)/4大杯(买入)/3中杯(增持无估值上调)/2温吞(中性或转谨慎)/**1其实看空(仍挂买入但下调EPS·调出金股·首推降级)**/0弃(停覆盖)。

**Tier-1抓取关键词**:
- 🔼上调:上调盈利预测/上调EPS/上修业绩预期/上调目标价/首次覆盖+买入/调入金股/首推措辞新增
- 🔽下调:下调盈利预测/下调目标价/调出金股/首推降级/覆盖降频·停止覆盖/语气转谨慎

**滚动30天新颖度**:
- 🆕本月新增(30天内首现/久违重提)· 🔼🔽变化(评级/目标价/预测修正)· 🔥共识形成(≥3家新增同向)· ⚡分歧新增(一家上调一家下调)· ♻️重复老信号(≥3天无变化→折叠)

`Δconviction下滑`(如5→3,名义仍买入)= 真负面信号。

## 7. 输出规范

### 7.1 三件产出
- **精简版(.txt)**:纯文本、结构同下、可直接复制发微信。
- **详细版(.md)**:全覆盖+每区展开+附一致预期表+分子板块速览表。
- **仪表盘(.html)**:米色dashboard风格(JetBrains Mono字体、一页纸)。

### 7.2 开头「今日要点」
3-6条独立短句,全是**最重要的变化**(事实陈述、带数字),不演绎、不泛泛总论。

### 7.3 各区写法
- 一、公司动态【事实】:只列变化(换帅/业绩披露/重大公告),一句话+数字+`公告/业绩会`。
- 二、行情/数据【事实】:只摘最重要变化,客观数据查实(总要求④)。
- 三、券商观点【观点】:focus 🔼/🔽/预测调整/观点转向,标机构+日期;维持类折叠。
- 四、专家纪要:`主题 | 来源 | 时间 | 专家背景`+一句核心数字。
- 五、市场段子【观点·未验证】:逐条标层级,禁当事实。
- 附:一致预期表(iFind),标"滞后、仅参考"。

### 7.4 文风
结论先行+大白话/类比;禁情绪词(超/不及预期);百分比注明度量对象。

## 8. 落盘与收尾

1. 精简版 → `outputs/YYYYMMDD_消费[早/晚]报_精简版.txt`
2. 详细版 → `outputs/YYYYMMDD_消费[早/晚]报.md`
3. HTML → `outputs/YYYYMMDD_消费[早/晚]报.html`
4. Chat汇报最重要变化+结论。
5. 提醒:草稿待签字,手动发送。

## 9. WorkBuddy自动化配置(定时双跑)

创建两个automation:

**早报 automation**:
- prompt: "按 consumer-pm-daily-brief skill 跑今日消费早报,覆盖日期为今日"
- scheduleType: recurring
- rrule: `FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR` (工作日)
- cwds: `C:\Users\ZhouH\Desktop\Claudes Pool`
- 建议触发时间: 08:00

**晚报 automation**:
- prompt: "按 consumer-pm-daily-brief skill 跑今日消费晚报,覆盖日期为今日"
- scheduleType: recurring
- rrule: `FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR`
- cwds: `C:\Users\ZhouH\Desktop\Claudes Pool`
- 建议触发时间: 16:30

### 前置依赖(配自动化前完成)
- ✅ iFind MCP (stock+news)
- ✅ Wind MCP (stock+global+fund)
- ✅ Comein MCP (comein-brm)
- ✅ AceCamp Python API (config: `自动化工作流-skill合集/E_数据接口与连接器/acecamp-research/scripts/config.json`)
- ⚠️ Info-Bridge MCP (需在Connector管理页信任 `info-bridge` 服务器)
- ⚠️ ThirdBridge 本地存档 (路径: `每日数据跟踪&Idea来源/纪要知识库_待归档/_raw/`, 浏览器端手动下载后存入)

## 10. 执行步骤(WorkBuddy版核心流程)

### L0 并行取数(用Agent工具同时发6个子任务):

**子任务A — Comein取数（必须覆盖全部消费子板块）**:
```
调用Comein MCP: **必须按11个子板块分query并行搜索**（禁止仅搜食饮）:
- search_domestic_reports: "白酒 消费 食品饮料 乳制品 调味品 啤酒" topK=8
- search_domestic_reports: "汽车 比亚迪 吉利 赛力斯 拓普 德赛西威 销量 智能驾驶" topK=5
- search_domestic_reports: "家电 美的 格力 海尔 以旧换新 国补" topK=5
- search_domestic_reports: "农业 养殖 牧原 温氏 生猪 猪价" topK=5
- search_domestic_reports: "商贸零售 黄金珠宝 老铺 潮宏基 免税 纺服" topK=5
- search_domestic_reports: "社服 美护 酒店 旅游 博彩 医美 珀莱雅 贝泰妮" topK=5
- search_domestic_reports: "轻工 家居 造纸 包装 晨光 欧派 索菲亚" topK=5
- search_analyst_comments: "消费 白酒 食品 零售 汽车 家电 农业 点评" topK=8
- search_roadshow_summary: "消费 路演 调研 纪要 白酒 零售" topK=5
返回研报标题/摘要/日期/机构,筛选近3天。各板块至少1条query,确保全覆盖。
```

**子任务B — Info-Bridge取数**:
```
调用Info-Bridge MCP retrieve,RAG检索消费板块市场段子:
keywords: "消费 白酒 食品 零售 餐饮 免税 美护 汽车 家电"
metadata_filter: 近3天;limit: 20
返回市场流传信息,标L1传闻/L2卖方圈内/L3段子。
```

**子任务C — iFind取数**:
```
调用iFind MCP:
1. search_notice: 近2天消费板块公司公告
2. search_news: 消费板块重点公司新闻
3. get_stock_financials: 一致预期(重点标的)
返回公告/新闻/一致预期数据。
```

**子任务D — Wind/FMP行情取数**:
```
调用Wind MCP + FMP:
1. Wind get_stock_quote: 港股消费标的实时行情
2. FMP quote: 美股中概(PDD/VIPS/LKNCY/CHA/ATAT)
3. WebSearch: 现货黄金/飞天茅台批价/汇率校实
返回行情异动(±5%)+客观价格数据。
```

**子任务E — AceCamp专家纪要取数**:
```
调用AceCamp Python API (base_url: https://api.acecamptech.com, key已配于config.json):
脚本: 自动化工作流-skill合集/E_数据接口与连接器/acecamp-research/scripts/acecamp_client.py

并行执行 (knowledge_search 是主搜索入口):
1. 搜索消费板块纪要:
   python acecamp_client.py knowledge_search --keyword "乳制品 原奶 供需" --per-page 5
   python acecamp_client.py knowledge_search --keyword "白酒 批价 渠道" --per-page 5
   python acecamp_client.py knowledge_search --keyword "食品饮料 调味品 量贩零食 肉制品" --per-page 5
   python acecamp_client.py knowledge_search --keyword "零售 免税 黄金珠宝 跨境电商" --per-page 5
   python acecamp_client.py knowledge_search --keyword "美妆 医美 美护" --per-page 5

2. 获取今日待开会议(仅当天可查,通常为空):
   python acecamp_client.py recent_meetings

注意: knowledge_search 返回的结果中 [知识库文档 ID] 可用于 note_detail 获取全文。
Timeout: 300s per call. 搜索前先 check_env 确认配置正常。
```

**子任务F — 本地存档扫描(ThirdBridge + 日报)**:
```
1. 读取最近2天的ThirdBridge本地存档:
   路径: 每日数据跟踪&Idea来源/纪要知识库_待归档/_raw/YYYYMMDD/
   匹配: thirdbridge_*.txt (搜索消费板块相关)
   提取: 标题、公司/主题、核心数字、结论

2. 读取最近2天日报存档:
   路径: 每日数据跟踪&Idea来源/
   抽取已标出的关键变化/信号,避免重复取数
```

### L1 浓缩初筛
将6源结果合并:跨源去重、打标(标的/主题·信号类型·是否重仓·是否敏感)。

### L2 策展+成稿
1. 按重要性分级(§5.1):重点详写/一行扫过/折叠
2. 卖方信号解码(§6):Δconviction/novelty
3. 按来源类型分区(§5.2)组织内容
4. 三点判断校准:有信心→给方向+理由;没想清→给市场解读;市场没解读→直说待讨论

### L3 输出
生成精简版.txt + 详细版.md + 仪表盘.html,落盘到outputs/。

## 纪律

- 时效性:股价/市值/批价WebSearch校实,不用训练记忆
- 严谨性:事实/观点分离、A/B/C追溯、卖方解码反Citation Laundering
- 落可量化变量:不代下评级/仓位/时点决策
- 结论先行:折叠老信号、变化优先
- 取数并行:L0取数不占主上下文;综合判断不可降级
